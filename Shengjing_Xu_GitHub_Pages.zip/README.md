# Shengjing Xu: Academic Homepage

An English academic homepage for GitHub Pages. No build step or dependencies are required. All content and styling live in `index.html`.

## 预览

下载并解压网站压缩包，双击 `index.html` 即可查看。CV 链接对应 `assets/Shengjing_Xu_CV.pdf`。

另附的 `Shengjing_Xu_Homepage.html` 是单文件预览，已内嵌相同的 CV，下载后可直接用浏览器打开。上传到 GitHub 时请使用压缩包中的文件。

## 发布到 GitHub Pages

1. 登录你的 GitHub 账户，创建名为 `你的用户名.github.io` 的仓库。名称必须与账户用户名对应；普通免费账户请设为 Public。
2. 将本包中的 `index.html`、`assets` 文件夹和 `.nojekyll` 上传到仓库根目录。不要再套一层目录；不要把 ZIP 文件本身当作网站上传。
3. 打开仓库的 **Settings → Pages**。
4. 在 **Build and deployment** 中选择 **Deploy from a branch**，分支选择 `main`，目录选择 `/(root)`，点击 **Save**。
5. 等待 GitHub 完成发布。你的网址为 `https://你的用户名.github.io/`；Pages 设置页会显示实际地址。

如果已经有个人主页仓库，请先保留原站内容，再合并这些文件。

官方说明：[Creating a GitHub Pages site](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site)。

## 日后更新

- 修改个人介绍、job market 状态、近期活动、论文和报告：编辑 `index.html` 中相应的 HTML 区块。
- 修改颜色：编辑文件顶部 `:root` 中的颜色值；整页背景渐变位于 `body` 样式中。
- 顶部导航栏使用 `assets/asen-after-rain-cover.jpg` 的局部作为背景；裁切位置和浅色遮罩位于 `.site-header` 样式中。
- 更新 CV：以相同文件名替换 `assets/Shengjing_Xu_CV.pdf`。
- 更新照片：替换 `assets/Shengjing_Xu.jpg`，并按新照片尺寸更新 HTML 中的 `width` 和 `height`。桌面版照片位于个人介绍右侧，手机上自动移至介绍上方。
- 更新页脚中的月份；论文的 Submitted 等状态也需要随实际情况更新。
- 页面包含桌面、平板和手机布局。内容不依赖 JavaScript、外部字体或第三方统计服务。

## 内容依据

基于 Shengjing Xu 的 2026-09-17 CV、研究陈述与已确认的报告安排。七篇公开论文的标题、作者和链接已与 arXiv 核对；三项正在撰写的工作单独列入 In preparation。

页面使用原创排版，参考以下学术主页的信息组织：

- [Jiaoyang Huang](https://jiaoyang.github.io/)
- [Daebeom Choi](https://sites.google.com/sas.upenn.edu/daebeom-choi/home)
- [Guangyi Zou](https://the8ravo.github.io/)
- [Shaowu Zhang](https://www.shaowuzhang.com/)

更新日期：2026-09-29。交付文件本身不会自动创建 GitHub 仓库或完成上线。

2026-09-29：将 Qin’s quasimodularity conjecture for Hilbert schemes of points 从 In preparation 移至 Papers & preprints 首项，添加 [arXiv:2609.33884](https://arxiv.org/abs/2609.33884)，并移除该项的草稿索取说明。


## 2026-09-27 内容调整

- 个人介绍增加 Tony Pantev 和 Xin Sun 的主页链接，Xin Sun 使用北大 BICMR 教师目录列出的新主页。
- 研究介绍使用 complex algebraic geometry and probability，说明 Higgs bundles、flat connections 与 Langlands 的联系，以及 probabilistic Liouville theory、random surfaces、random matrices 和 particle systems。
- 加粗强调 2026-2027 academic job market。
- 近期活动仅列即将到来的 Stony Brook 报告和 AMS Fall Eastern Sectional Meeting；Maryland 保留在过去的研究报告中。
- 论文区保留题目、作者、状态和 arXiv 链接，删除研究解读和独立 PDF 链接。
- 移除 AI-assisted mathematics 栏目和导航入口。
- Caltech/USC 联合报告地点改为 University of Southern California；2022 年夏季报告题目改为 Liouville quantum gravity sphere。

CV PDF 保持原文件。近期活动依据官方日历、会议安排和本人提供的确认邮件。

顶部导航栏使用艾志恒 ASEN《在雨后醒来》专辑封面的云层与建筑局部，并叠加浅色遮罩，保持姓名与导航文字清晰。正文背景保留淡蓝灰渐变。封面来源：[Apple Music 专辑页](https://music.apple.com/cn/album/在雨后醒来/1845141403)，封面摄影：戴晓艺。封面图版权归原权利人所有。
